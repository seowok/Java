package view;

import javax.swing.JTextArea;

public class RightText extends JTextArea{
	public RightText()
	{
		setText("Right");
	}
}
