package model.compare;

public abstract class Line {
	String line;
}
