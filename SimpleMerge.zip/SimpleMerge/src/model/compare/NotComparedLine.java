package model.compare;

public class NotComparedLine extends Line{
	
	NotComparedLine(String str){
		this.line = str;
	}
	
}
