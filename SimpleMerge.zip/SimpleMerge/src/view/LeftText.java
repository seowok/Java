package view;

import javax.swing.JTextArea;

public class LeftText extends JTextArea{
	public LeftText()
	{
		setText("Left");
	}
}
